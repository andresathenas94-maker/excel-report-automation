# Automatizador de reportes de Excel

## El problema
Muchas empresas reciben archivos de ventas separados (uno por sucursal), con datos desordenados, y alguien pasa horas cada semana uniéndolos y armando el reporte a mano.

## La solución
Un script que une todos los archivos, limpia los datos (espacios, mayúsculas, fechas, duplicados) y genera un Excel con formato profesional: resumen, ventas por producto, por mes y por región, más un gráfico.

**Resultado:** un reporte de varias horas se genera en segundos.

## Cómo usarlo
```bash
pip install -r requirements.txt
python generar_datos.py      # crea datos de ejemplo (inventados)
python reporte.py            # genera resultado/reporte_ventas.xlsx
python reporte.py mi_carpeta # usa tus propios CSV
```
Los CSV deben tener las columnas: `fecha, producto, region, cantidad, precio_unitario`.

## Herramientas
Python, pandas, openpyxl.

## ¿Necesitas algo parecido para tu negocio?
Adapto el script a tus archivos y a tu formato de reporte. Escríbeme.
