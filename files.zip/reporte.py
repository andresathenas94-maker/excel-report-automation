"""Automatizador de reportes: une varios CSV, limpia y genera un Excel con resumen y gráfico."""
import sys
from pathlib import Path

import pandas as pd
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill

CARPETA = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("datos_ejemplo")
SALIDA = Path("resultado/reporte_ventas.xlsx")


def cargar(carpeta: Path) -> pd.DataFrame:
    archivos = sorted(carpeta.glob("*.csv"))
    if not archivos:
        sys.exit(f"No se encontraron CSV en {carpeta}")
    partes = []
    for a in archivos:
        df = pd.read_csv(a)
        df["origen"] = a.stem
        partes.append(df)
    return pd.concat(partes, ignore_index=True)


def limpiar(df: pd.DataFrame) -> pd.DataFrame:
    df["producto"] = df["producto"].str.strip().str.title()
    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce")
    df = df.dropna(subset=["fecha", "cantidad", "precio_unitario"]).drop_duplicates()
    df["total"] = df["cantidad"] * df["precio_unitario"]
    df["mes"] = df["fecha"].dt.to_period("M").astype(str)
    return df


def dar_formato(ws, ancho=18):
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F4E78")
        c.alignment = Alignment(horizontal="center")
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = ancho


def main():
    df = limpiar(cargar(CARPETA))
    por_producto = df.groupby("producto", as_index=False)[["cantidad", "total"]].sum().sort_values("total", ascending=False)
    por_mes = df.groupby("mes", as_index=False)["total"].sum()
    por_region = df.groupby("region", as_index=False)["total"].sum().sort_values("total", ascending=False)
    resumen = pd.DataFrame({
        "Indicador": ["Ventas totales", "Unidades vendidas", "Número de ventas", "Ticket promedio"],
        "Valor": [round(df["total"].sum(), 2), int(df["cantidad"].sum()), len(df), round(df["total"].mean(), 2)],
    })

    SALIDA.parent.mkdir(exist_ok=True)
    with pd.ExcelWriter(SALIDA, engine="openpyxl") as w:
        resumen.to_excel(w, sheet_name="Resumen", index=False)
        por_producto.to_excel(w, sheet_name="Por producto", index=False)
        por_mes.to_excel(w, sheet_name="Por mes", index=False)
        por_region.to_excel(w, sheet_name="Por region", index=False)
        df.drop(columns="mes").to_excel(w, sheet_name="Datos limpios", index=False)
        for ws in w.book.worksheets:
            dar_formato(ws)
        ws = w.book["Por producto"]
        graf = BarChart()
        graf.title = "Ventas por producto"
        graf.add_data(Reference(ws, min_col=3, min_row=1, max_row=len(por_producto) + 1), titles_from_data=True)
        graf.set_categories(Reference(ws, min_col=1, min_row=2, max_row=len(por_producto) + 1))
        ws.add_chart(graf, "E2")

    print(f"Reporte generado: {SALIDA}  ({len(df)} registros procesados)")


if __name__ == "__main__":
    main()
