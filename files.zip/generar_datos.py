"""Genera archivos CSV de ventas INVENTADOS para probar el automatizador."""
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)
carpeta = Path("datos_ejemplo")
carpeta.mkdir(exist_ok=True)

productos = {"Laptop": 750, "Monitor": 210, "Teclado": 45, "Mouse": 25, "Auriculares": 60}
regiones = ["Norte", "Sur", "Este", "Oeste"]

for sucursal in ["sucursal_central", "sucursal_norte", "sucursal_sur"]:
    filas = ["fecha,producto,region,cantidad,precio_unitario"]
    for _ in range(150):
        f = date(2026, 1, 1) + timedelta(days=random.randint(0, 270))
        p = random.choice(list(productos))
        # Datos algo sucios a propósito: mayúsculas mezcladas y espacios
        nombre = random.choice([p, p.upper(), f" {p} "])
        filas.append(f"{f},{nombre},{random.choice(regiones)},{random.randint(1, 8)},{productos[p]}")
    (carpeta / f"{sucursal}.csv").write_text("\n".join(filas), encoding="utf-8")

print("Datos de ejemplo creados en", carpeta)
